# Men of the Docks — narration-led edit plan

**1920 × 1080 · 30 fps · Rec.709 · voice-led museum film**

The supplied script is the editorial source. All audio cue timings are provisional until checked in playback. The artwork and gallery are visible in the chat; the original painting's size is confirmed as 5935 × 4226. Their files were not exposed to this workspace. Version 3 supplies an animated picture timeline with offline references for local relinking. Use only those two images; no additional paintings, maps, or invented movement within the work.

## Shot progression

| Cue from the narration | Framing and action | Cut and pacing |
| --- | --- | --- |
| **“There is no ambiguity…”** | Open on the gallery wide. Introduce *Men of the Docks*, with “George Bellows · 1912” beneath it. Keep the title comfortably clear of the framed painting. | Begin with a short hold, followed by a very small push. Keep the gallery movement under about 4% initially. |
| **“a visual paradox of social hierarchy”** | Cut to the full, unframed artwork from the original image. Establish the relationship between the small figures and the enormous vessel. | A clean cut makes the change of source intentional. Do not attempt a continuous zoom through the lower-resolution mockup. |
| **“Before us lies a squalid New York dockside…”** | Hold the full composition, then drift modestly toward the river, snow, and industrial waterfront. Preserve enough of the city and ship to locate the scene. | Give viewers time to inspect the composition. No added snow, fog, frost, or animated water. |
| **“In the foreground, impasto brown sludge…”** | Favor the lower foreground. Let the painted texture read without excessive enlargement or added sharpening. | Cut on the new idea. A short static hold can reveal brushwork more clearly than continuous movement. |
| **“A dockside bollard…” → “It waits, as do…”** | Frame the bollard with the group still visible; make one restrained move toward the workers. | This is one visual comparison. Keep both the object and people connected rather than using two unrelated extreme close-ups. |
| **“Their foreman stands front and center…”** | Center the back-facing foreground figure, retaining nearby workers. End slightly closer on the heavy clothing and posture if resolution allows. | Slow push. Do not add a label that independently identifies the figure as a foreman. |
| **“To the left, a rejected figure…”** | Cut to the figure by the dark warehouse. Keep the surrounding shadow and some empty space. | A nearly static shot should make this section feel isolated. Do not animate the figure walking. |
| **“Across the water…”** | Frame the Manhattan skyline with the river still visible. Let distance remain legible. | Cut to the upper-left region. A small upward drift is sufficient. |
| **“separating the horse and cart…”** | If the phrase has enough time, widen to reconnect the skyline with the foreground horses. Otherwise maintain the skyline view and let the next wide shot carry the comparison. | Avoid a rapid pan across the entire painting. Use a cut if two views are needed. |
| **“In the gathered crowd…” → “a single bright blue jumper…”** | Begin with the group, then favor the blue-clad figure while retaining surrounding dark coats. | The blue should emerge naturally through framing. No glow, saturation pulse, arrow, or inserted Cézanne image. |
| **“A Liverpool ship…”** | Show the liner's hull and superstructure together, then a gentle upward reveal toward the decks and funnel. | Cut to this much larger shape. Retain enough hull to preserve its scale against the people. |
| **“Bellows captured the epitome…”** | Return to a broad view linking the workers, ship, and city. | Widen with a clean cut, then settle. This is the first reflective reset after the detail sequence. |
| **“Bellows painted on his own terms…”** | Use the complete artwork, or a modest wide crop showing the people against the vessel. | A quiet hold is appropriate. Let the commentary lead. |
| **“This work eventually crossed the Atlantic…”** | Remain with the whole artwork. The gallery setting can return later, after the concluding argument. | Do not imply that the supplied mockup is the actual institution where the painting is held. No animated travel route. |
| **“Men of the Docks stands as…”** | Give the painting a final, unobstructed full view. Keep the waiting workers readable. | Nearly static. Keep credits off the work during this sentence. |
| **“Men of the Docks. By James Darcy.”** | Return to the gallery wide and let a restrained end credit appear. Keep a short final visual hold after the voice ends. | A soft dissolve is suitable here if it does not double the framed artwork distractingly. |

## Motion and layout

Use one simple move per shot. Start with 3–6% scale changes over roughly 6–10 seconds, then adjust to the actual narration. Alternate moving views with still holds. Avoid ending every shot at the same speed or introducing a dissolve at every paragraph.

When the entire painting is shown, preserve all edges and its aspect ratio. A charcoal surround is preferable to stretching or accidental cropping. For details, keep the source crop large enough for 1080p delivery; confirm at 100% output scale before accepting a close-up.

For the authored version 3 timeline, **do not apply Set to Frame Size or Scale to Frame Size** over the calculated transforms. Motion → Scale and Position are already animated for the declared dimensions. `PICTURE_SETTINGS.md` and `PREMIERE_MOTION_KEYFRAMES.csv` record the exact values. Check subject placement against the relinked originals and inspect the first and last seconds of every move for abrupt stops.

Use warm off-white type, generous margins, and a restrained serif title. A practical starting point is a title around 60–72 px and a secondary credit around 26–32 px at 1080p, adjusted to the selected font. Keep essential text at least 96 px from either side and 54 px from the top or bottom. Avoid oversized titles across the painting.

## End credit

*Men of the Docks*  
**Painting · George Bellows, 1912**  
**Commentary · James Darcy**

“Commentary” separates the script's closing attribution from the artist's credit without assuming Darcy is the recorded performer. Confirm the desired role wording before the final export.

## Editorial treatment

Preserve the supplied narration. Do not add captions asserting the identity of a foreman, a rejected worker, the Cézanne connection, or the exact ship independently of the commentary. These points are interpretive or historical claims in the script; this edit plan has not independently fact-checked them. The visual treatment should direct attention to what is visible in the painting.

## Finishing

Build the first cut around the voice alone. No music is bundled or required. If music is added later, choose a licensed, restrained instrumental bed and balance it by listening for intelligibility; do not use a fixed volume offset as a substitute for mixing.

Version 3 implements 14 physical shots, combining several emphasis cues within continuous moves. A short medium view of the people against the vessel supports “Bellows painted on his own terms” before the final complete view. Review the finished video in real time for subject-to-phrase timing, crop clarity, readable credits, picture quality, audio peaks, and the final hold. Export a 1080p H.264 review file before creating the delivery master. Native Premiere import, playback with the local images, and the finished render remain to be tested on the editing machine.
